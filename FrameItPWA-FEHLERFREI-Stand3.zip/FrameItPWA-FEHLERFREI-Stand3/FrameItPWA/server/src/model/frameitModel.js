import { query } from '../../boilerplate/db/index.js';

export const getVideos = async () => {
  const { rows } = await query(
    'select * from videos',
  );
  return rows;
};

export const deleteVideo = async (id) => {
  const { rows } = await query(
    'delete from videos where id = $1 returning *',
    [id]
  );
  return rows;
};
