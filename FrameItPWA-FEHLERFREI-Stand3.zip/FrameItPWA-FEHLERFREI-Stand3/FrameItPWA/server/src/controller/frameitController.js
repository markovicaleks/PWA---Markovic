import asyncHandler from 'express-async-handler';
import * as model from '../model/frameitModel.js';

export const getVideos = asyncHandler(async (req, res) => {
  res.status(200).json(await model.getVideos());
});

export const deleteVideo = asyncHandler(async (req, res) => {
  const { id } = req.params;
  res.status(202).json(await model.deleteVideo(id));
});