import { defineStore } from 'pinia';
import { ref } from 'vue';
import axios from 'axios';

export const useVideoStore = defineStore('videoStore', () => {
  // State
  const videos = ref([]);
  const errorMessage = ref(null); // Fehlernachricht hinzugefügt

  // Actions
  const fetchVideo = async () => {
    try {
      const { data } = await axios.get('http://localhost:3000/videos');
      if (JSON.stringify(videos.value) !== JSON.stringify(data)) {
        videos.value = Object.freeze([...data]); // Verhindert ungewollte Reaktivität
      }
    } catch (error) {
      errorMessage.value = error.message || 'Failed to fetch data';
    }
  };

  return {
    videos,
    errorMessage, // Fehlernachricht zurückgeben
    fetchVideo,
  };
});
