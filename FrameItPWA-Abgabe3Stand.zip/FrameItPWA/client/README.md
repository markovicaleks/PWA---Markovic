# Vue 3 client with Quasar

This template should help get you started developing with Vue 3, Vite and Quasar. It contains 3 Google Fonts.

## Recommended IDE Setup

Check my Profile for setup: https://vscode.dev/profile/github/ac852643a4faef8ba255ef97a5f8c823

## Customize configuration

See [Vite Configuration Reference](https://vitejs.dev/config/).

## Project Setup

```sh
npm install
```

### Compile and Hot-Reload for Development

```sh
npm run dev
```

### Compile and Minify for Production

```sh
npm run build
```

### Lint with [ESLint](https://eslint.org/)

```sh
npm run lint
```
