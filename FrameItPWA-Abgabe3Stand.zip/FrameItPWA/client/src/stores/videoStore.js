import { defineStore } from 'pinia';
import { ref } from 'vue';
import axios from 'axios';

export const useVideoStore = defineStore('videoStore', () => {
  // State
  const videos = ref([]);

  // Actions
  const fetchVideo = async () => {
    try {
      const { data } = await axios.get('http://localhost:3000/videos');
      videos.value = data;
    } catch (error) {
      errorMessage.value = error.message || 'Failed to fetch data';
    }
  };

  return {
    videos,
    fetchVideo
  };
});
