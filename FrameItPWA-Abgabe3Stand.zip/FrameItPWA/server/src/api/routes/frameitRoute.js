import express from 'express';
import { getVideos, deleteVideo } from '../../controller/frameitController.js';

const router = express.Router();

router.get('/', getVideos);
router.delete('/:id', deleteVideo);

export default router;